/* general-map.js — Geoapify Geocoding + Places + Static Map API (no external libraries) */

var API_KEY = 'e2a5d19ce52c4d52b19539056f90b20d';
var currentPlaces = [];
var currentLat = null;
var currentLon = null;
var currentZoom = 13;   // default zoom level
var MIN_ZOOM = 5;
var MAX_ZOOM = 19;

document.getElementById('cityInput').addEventListener('keyup', function (e) {
    if (e.key === 'Enter') searchPlaces();
});

async function searchPlaces() {
    var city = document.getElementById('cityInput').value.trim();
    if (!city) { alert('Please enter a city name.'); return; }

    setStatus('🔍 Finding location…');
    document.getElementById('placesList').innerHTML = '';
    document.getElementById('resultCount').textContent = '';
    document.getElementById('mapImg').style.display = 'none';
    document.getElementById('zoomControls').style.display = 'none';
    currentZoom = 14;

    // ── Step 1: Geocode city name ────────────────────────────────────
    var geoUrl = 'https://api.geoapify.com/v1/geocode/search?text=' +
        encodeURIComponent(city) + '&limit=1&apiKey=' + API_KEY;

    var lat, lon;
    try {
        var geoRes = await fetch(geoUrl);
        var geoData = await geoRes.json();

        if (!geoData.features || !geoData.features.length) {
            setStatus('❌ City not found. Please try another name.');
            return;
        }

        lon = geoData.features[0].geometry.coordinates[0];
        lat = geoData.features[0].geometry.coordinates[1];
        currentLon = lon;
        currentLat = lat;
    } catch (e) {
        setStatus('❌ Geocoding failed. Check internet connection.');
        return;
    }

    // ── Step 2: Fetch nearby interesting places ──────────────────────
    setStatus('📍 Loading interesting places…');
    currentZoom = 14;

    var placesUrl = 'https://api.geoapify.com/v2/places' +
        '?categories=tourism,entertainment,heritage,natural,building.tourism' +
        '&filter=circle:' + lon + ',' + lat + ',8000' +
        '&limit=20' +
        '&apiKey=' + API_KEY;
    try {
        var plRes = await fetch(placesUrl);
        var plData = await plRes.json();
        currentPlaces = plData.features || [];
    } catch (e) {
        setStatus('❌ Could not fetch places. Check internet connection.');
        return;
    }

    if (!currentPlaces.length) {
        setStatus('No interesting places found within 8 km.');
        return;
    }

    clearStatus();
    document.getElementById('resultCount').textContent =
        currentPlaces.length + ' interesting places near ' + city;
    document.getElementById('zoomControls').style.display = 'flex';

    // ── Step 3: Build Static Map URL with markers ────────────────────
    var markerParts = currentPlaces.slice(0, 20).map(function (place, i) {
        var plon = place.geometry.coordinates[0];
        var plat = place.geometry.coordinates[1];
        return 'lonlat:' + plon + ',' + plat + ';color:%23ff6b6b;size:medium;text:' + (i + 1);
    });

    refreshMap(markerParts);

    // ── Step 4: Build sidebar cards ──────────────────────────────────
    var placesList = document.getElementById('placesList');

    currentPlaces.forEach(function (place, index) {
        var props = place.properties;
        var name = props.name || props.address_line1 || 'Unnamed place';
        var addr = props.address_line2 || '';
        var cat = props.categories ? props.categories[0].replace(/_/g, ' ') : '';

        var card = document.createElement('div');
        card.className = 'place-card';
        card.innerHTML =
            '<div class="place-number">' + (index + 1) + '</div>' +
            '<div class="place-info">' +
            '<h3>' + name + '</h3>' +
            (addr ? '<p class="place-dist">📍 ' + addr + '</p>' : '') +
            (cat ? '<p class="place-dist">🏷 ' + cat + '</p>' : '') +
            '</div>';

        // Click card → re-centre static map on that specific place
        card.addEventListener('click', function () {
            var plon = place.geometry.coordinates[0];
            var plat = place.geometry.coordinates[1];

            var zoomedUrl =
                'https://maps.geoapify.com/v1/staticmap' +
                '?style=osm-carto' +
                '&width=900&height=650' +
                '&center=lonlat:' + plon + ',' + plat +
                '&zoom=17' +
                '&marker=lonlat:' + plon + ',' + plat + ';color:%23ff6b6b;size:large' +
                '&apiKey=' + API_KEY;

            mapImg.src = zoomedUrl;

            document.querySelectorAll('.place-card').forEach(function (c) {
                c.classList.remove('active');
            });
            card.classList.add('active');
        });

        placesList.appendChild(card);
    });
}

// ── Zoom controls ─────────────────────────────────────────────────
function zoomIn() {
    if (currentZoom < MAX_ZOOM) { currentZoom++; refreshMap(); }
}

function zoomOut() {
    if (currentZoom > MIN_ZOOM) { currentZoom--; refreshMap(); }
}

function refreshMap(markerParts) {
    if (currentLat === null) return;

    // Build markers from current places if not passed in
    if (!markerParts) {
        markerParts = currentPlaces.slice(0, 20).map(function (place, i) {
            var plon = place.geometry.coordinates[0];
            var plat = place.geometry.coordinates[1];
            return 'lonlat:' + plon + ',' + plat + ';color:%23ff6b6b;size:medium;text:' + (i + 1);
        });
    }

    var url =
        'https://maps.geoapify.com/v1/staticmap' +
        '?style=osm-carto' +
        '&width=900&height=650' +
        '&center=lonlat:' + currentLon + ',' + currentLat +
        '&zoom=' + currentZoom +
        (markerParts.length ? '&marker=' + markerParts.join('|') : '') +
        '&apiKey=' + API_KEY;

    var mapImg = document.getElementById('mapImg');
    // Fade out → swap src → fade in
    mapImg.style.opacity = '0';
    mapImg.style.display = 'block';
    document.getElementById('mapPlaceholder').style.display = 'none';

    setTimeout(function () {
        mapImg.src = url;
        mapImg.onload = function () {
            mapImg.style.opacity = '1';
        };
    }, 150);

    // Update zoom counter
    document.getElementById('zoomLevel').textContent = 'Zoom: ' + currentZoom;
}

function setStatus(msg) {
    var s = document.getElementById('statusMsg');
    s.textContent = msg;
    s.style.display = 'block';
}

function clearStatus() {
    var s = document.getElementById('statusMsg');
    s.textContent = '';
    s.style.display = 'none';
}
