/* general.js — Integrated from rakeshsent/Njva.js */

/* ─── Gold Rate Calculator ───────────────────────────────────────── */
function calculateWealth() {
    const grams = parseFloat(document.getElementById("goldAmount").value);
    const rate22K = 14540; // Today's rate per gram (22K)

    if (grams > 0) {
        const total = grams * rate22K;
        document.getElementById("resultDisplay").innerText =
            "Total Value: ₹" + total.toLocaleString("en-IN");
    } else {
        alert("Please enter a valid amount of gold!");
    }
}

/* ─── Weather Lookup ─────────────────────────────────────────────── */
async function getWeather() {
    const city = document.getElementById("cityInput").value.trim();
    const resultDiv = document.getElementById("conditionDisplay");
    const tempDiv = document.getElementById("tempDisplay");
    const weatherResult = document.getElementById("weatherResult");

    if (!city) {
        alert("Please enter a city name!");
        return;
    }

    resultDiv.innerText = "Loading…";
    tempDiv.innerText = "";
    weatherResult.classList.add("visible");

    try {
        // Step 1: Geocode the city name
        const geoRes = await fetch(
            `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`
        );
        const geoData = await geoRes.json();

        if (!geoData.results || geoData.results.length === 0) {
            resultDiv.innerText = "City not found!";
            tempDiv.innerText = "";
            return;
        }

        const { latitude, longitude } = geoData.results[0];

        // Step 2: Fetch weather using coordinates
        const weatherRes = await fetch(
            `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`
        );
        const weatherData = await weatherRes.json();

        const temp = weatherData.current_weather.temperature;
        const code = weatherData.current_weather.weathercode;

        // Step 3: Map weather code to condition label
        let condition = "Clear Skies";
        if (code >= 1  && code <= 3)  condition = "Partly Cloudy";
        if (code >= 45 && code <= 48) condition = "Foggy";
        if (code >= 51 && code <= 67) condition = "Rainy";
        if (code >= 71 && code <= 86) condition = "Snowy";
        if (code >= 95)               condition = "Stormy";

        tempDiv.innerText   = temp + "°C";
        resultDiv.innerText = condition;

    } catch (error) {
        resultDiv.innerText = "Error fetching weather. Please try again.";
        tempDiv.innerText   = "";
    }
}

/* ─── Allow Enter key in weather input ──────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
    const cityInput = document.getElementById("cityInput");
    if (cityInput) {
        cityInput.addEventListener("keyup", (e) => {
            if (e.key === "Enter") getWeather();
        });
    }
});

/* ─── Logout / Role Switch ───────────────────────────────────────── */
function logout() {
    if (confirm("Are you sure you want to log out?")) {
        window.location.href = "index.html";
    }
}

function switchRole() {
    if (confirm("Switch to Student Dashboard?")) {
        window.location.href = "student-dashboard.html";
    }
}

/* ─── Theme Toggle ──────────────────────────────────────────────── */
function toggleTheme() {
    document.body.classList.toggle("dark-theme");
    const isDark = document.body.classList.contains("dark-theme");
    localStorage.setItem("theme", isDark ? "dark" : "light");
}

// Apply saved theme on load
document.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
        document.body.classList.add("dark-theme");
    }
});
