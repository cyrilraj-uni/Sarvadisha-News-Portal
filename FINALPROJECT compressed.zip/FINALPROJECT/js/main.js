// Code to easily handle user roles

// Function to save user choice text to computer so other pages can read it
function saveUserRole(role) {
    localStorage.setItem('user_role', role);
}

// Function to get the saved choice. Defaults to 'general' if empty.
function getUserRole() {
    return localStorage.getItem('user_role') || 'general';
}

// Theme Toggle Logic
function initTheme() {
    const savedTheme = localStorage.getItem('app_theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
    }
}

function toggleTheme() {
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('app_theme', isLight ? 'light' : 'dark');
}

// Initialize theme on load automatically
initTheme();
